import axios from 'axios'
import history from '../history'
import socket from '../socket';



const defaultMessage = {
    newMessageEntry: '',
    messages: [],
    name: ''
}
// ACTION TYPES
const WRITE_MESSAGE = 'WRITE_MESSAGE';
const GET_MESSAGE = 'GET_MESSAGE'
const UPDATE_NAME = 'UPDATE_NAME';
const GOT_MESSAGES_FROM_SERVER = 'GOT_MESSAGES_FROM_SERVER'


// ACTION CREATORS
export const updateName = (name) => {
    return { type: UPDATE_NAME, name };
}

export const writeMessage = (content) => {
    return { type: WRITE_MESSAGE, content };
}

export const getMessage = (message) => {
    return { type: GET_MESSAGE, message };
}

export const gotMessagesFromServer = (messages) => ({
    type: GOT_MESSAGES_FROM_SERVER,
    messages
});

export const fetchMessages = () => {
    return async (dispatch) => {
        const response = await axios.get('/api/gif/');
        const messages = response.data;
        const action = gotMessagesFromServer(messages);
        dispatch(action);
    };
};




export const postMessage = (gifname, name) => {
    console.log(name)
    return async (dispatch) => {
        const response = await axios.post('/api/gif/', { name, gifname });
        const newMessage = response.data;
        const action = getMessage(newMessage);
        dispatch(action);
        socket.emit('new-message', newMessage);
    }
}

export default function (state = defaultMessage, action) {
    switch (action.type) {
        case GET_MESSAGE:
            return {
                ...state,
                messages: [...state.messages, action.message]
            };
        case WRITE_MESSAGE:
            return {
                ...state,
                newMessageEntry: action.content
            };

        case UPDATE_NAME:
            return {
                ...state,
                name: action.name
            };
        case GOT_MESSAGES_FROM_SERVER: {
            return { ...state, messages: action.messages };
        }
        default:
            return state
    }
}