'use strict'
/* global describe beforeEach it */

const seed = require('./seed')

describe('seed script', () => {
  it('completes successfully', seed)
})
